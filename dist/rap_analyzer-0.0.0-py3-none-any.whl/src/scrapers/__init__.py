"""Data Collection Layer - Web scrapers for lyrics and metadata."""
