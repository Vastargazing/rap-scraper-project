"""Data Models & Storage - Pydantic models and database operations."""
